const server = require('./server')

server.start()
