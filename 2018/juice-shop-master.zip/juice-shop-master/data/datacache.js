/* jslint node: true */
exports.challenges = {}
exports.users = {}
exports.products = {}
exports.feedback = {}
exports.baskets = {}
exports.basketItems = {}
exports.complaints = {}

exports.notifications = []
